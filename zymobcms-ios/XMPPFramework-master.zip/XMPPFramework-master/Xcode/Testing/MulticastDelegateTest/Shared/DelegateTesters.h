#import <Foundation/Foundation.h>


@interface DelegateTester1 : NSObject

@end

@interface DelegateTester2 : NSObject

@end

@interface DelegateTester3 : NSObject

@end
