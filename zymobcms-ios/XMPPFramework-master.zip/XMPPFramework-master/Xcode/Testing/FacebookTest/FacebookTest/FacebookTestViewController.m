#import "FacebookTestViewController.h"

@implementation FacebookTestViewController

@synthesize statusLabel;


@end
