//
//  ZYXMPPUser.m
//  ZYXMPPClient
//
//  Created by barfoo2 on 13-9-5.
//  Copyright (c) 2013年 ZYProSoft. All rights reserved.
//

#import "ZYXMPPUser.h"

@implementation ZYXMPPUser
@synthesize jID,state,user,domain,resource,password;

@end
