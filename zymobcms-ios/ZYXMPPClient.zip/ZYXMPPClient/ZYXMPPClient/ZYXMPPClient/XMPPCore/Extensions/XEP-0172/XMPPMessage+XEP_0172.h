#import <Foundation/Foundation.h>
#import "XMPPMessage.h"

@interface XMPPMessage (XEP_0172)

- (NSString *)nick;

@end
